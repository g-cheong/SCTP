function Container() {
    return (
        <>
        <h1>This is a Parent component</h1>
        <Child firstName="Tom" lastName="Fisher" age={8} hobbies={["Fishing", "Running"]} petType="fish"/>
        <Child firstName="Charlie" lastName="Tan" age={23} hobbies={["Cooking", "Eating"]} petType="dog"/>
        <Child firstName="Daisy" lastName="Lee" age={18} hobbies={["Reading", "Painting"]} petType="bird"/>
        <AnotherChild />
        </>
    );
}

export default Container;