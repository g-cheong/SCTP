import './Topic.css';

function Topic({topicName, itemArray}) {
    return (
        <div class="topic">
            <h2 className="topic-name">{topicName}</h2>
            <p className="subtopic">
                {itemArray.map(item => (<p style={{listStyleType:"none"}}>{item}</p>))}
                
            </p>
            <p className="subtopic"> View all questions</p>
        </div>
    );
}

export default Topic;