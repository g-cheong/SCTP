import './App.css';
import Topic from './components/Topic';

const genArray = ["About forwarding limits", "How to update WhatsApp", "How to change group privacy settings"]
const andriodArray = ["Verifying your number", "How to restore your chat history", "How to manage your notifications"]
const iphoneArray = ["How to restore your chat history", "How to manage your notifications", "How to use status"]
const webArray = ["About WhatsApp Web and Desktop", "How to log in or out", "How to manage your notifications"]
const kaiArray = ["How to verify your phone number", "How to edit your profile", "How to send media, contacts, or location"]
const wabusinessArray = ["WhatsApp business products", "How to download the WhatsApp Business app", "How to edit your business profile"]

function App() {
  return (
    
    <div class="container">
      <h1 class="help-header">Help Center</h1>
      <div class="topics-container" display="grid" align-item="start" background-color="white" grid-template-columns="repeat(3,1fr)">
        <Topic topicName="General" itemArray={genArray}/>
        <Topic topicName="Android" itemArray={andriodArray}/>
        <Topic topicName="iPhone" itemArray={iphoneArray}/>
        <Topic topicName="Web and Desktop" itemArray={webArray}/>
        <Topic topicName="KaiOS" itemArray={kaiArray}/>
        <Topic topicName="WhatsApp Business for Android" itemArray={wabusinessArray}/>
      </div>
    </div>
    
  );
}

export default App;
